Compile main.tex with XeLaTeX or Tectonic. Retain the included support_materials subdirectories.
A4 manuscript with margins of at least 25 mm, a separate abstract, continuous centered page numbers, and no contents page.
The class is distributed under the LaTeX Project Public License stated in elsarticle.cls.
This archive compiles the paper and its complete source listings. The separate scientific support archive supplies execution inputs, configuration, saved outputs and verification instructions.
